---
title: "{{ replace .Name "-" " " | title }}"
passage: ""
date: {{ .Date }}
audio: ""
audio_duration: "1:00"
audio_size: 1
preacher: ""
images: [""]
series: []
tags: []
draft: true
---
