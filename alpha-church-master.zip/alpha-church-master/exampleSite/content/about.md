---
title: "About"
subtitle: "About Alpha-Church"
date: 2018-04-30T10:05:49+10:00
images: ["/img/freely-20445.jpg"]
draft: false
---

This is an example about page.

With a bible quote for good measure!

> “For God so loved the world that he gave his one and only Son, that whoever believes in him shall not perish but have eternal life. For God did not send his Son into the world to condemn the world, but to save the world through him. Whoever believes in him is not condemned, but whoever does not believe stands condemned already because they have not believed in the name of God’s one and only Son.”

(John 3:16–18 NIV)

And a map
{{< map >}}
