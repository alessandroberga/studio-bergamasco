+++
title = "Image Style Guide"
date = 2017-11-14T08:08:17-05:00
tags = []
categories = []
+++

Veniam est eu adipisicing reprehenderit do sit sint elit sint. Tempor laborum ut dolore aliqua. Commodo eu qui sint magna veniam laborum. Ad cupidatat do proident ex veniam amet Lorem. Officia laboris aute fugiat id consequat culpa ullamco labore ea amet ad. Occaecat quis dolor commodo pariatur cillum et id id cupidatat officia.

Magna incididunt proident cupidatat cupidatat enim consectetur sunt. Ipsum velit aliqua ex ipsum qui labore magna. Ea nisi anim ad culpa Lorem occaecat ex cupidatat duis labore officia dolor.

{{< figure src="//via.placeholder.com/600x200" class="full" caption="Magna sunt ut ea quis aliqua cupidatat ut quis sit aliqua tempor duis." >}}

Aliqua minim esse velit est non. Ea do irure labore aliquip culpa ex ut sunt anim duis irure. Ex adipisicing deserunt do occaecat. Incididunt esse ea tempor fugiat magna.

Voluptate elit exercitation aliqua ut elit reprehenderit aliquip anim elit laborum laborum. Elit aute sint nisi labore irure in labore culpa. Fugiat velit fugiat ea reprehenderit. Sint minim amet occaecat eu labore reprehenderit pariatur nulla.

{{< figure src="//via.placeholder.com/600x300" class="mid" caption="Eu cupidatat ex qui do." >}}

In deserunt exercitation Lorem est nulla ullamco enim duis consequat tempor minim. Nostrud cillum ex dolore amet qui mollit do in aliquip consequat eiusmod est dolor officia. Exercitation quis cillum voluptate dolore cillum veniam minim voluptate ullamco voluptate reprehenderit deserunt elit. Et cillum sunt labore ad duis officia aute Lorem incididunt commodo ea.

Deserunt Lorem aliquip dolor et ut adipisicing nisi esse est dolore irure laborum. Excepteur dolor pariatur excepteur deserunt eiusmod laborum. Ad officia ea magna id ex. Laborum enim proident incididunt quis.

![floaty mcboaty](//via.placeholder.com/300x400#float-right)

Elit culpa ad ex aute ullamco dolor anim do labore. Non ex do eiusmod elit occaecat. Adipisicing mollit commodo fugiat qui Lorem cupidatat laboris consectetur. Anim nostrud ullamco excepteur Lorem aliqua ullamco nisi.

Dolor adipisicing magna cupidatat consequat commodo est deserunt enim amet nulla pariatur mollit. Cupidatat officia veniam adipisicing laboris et ullamco consequat est nisi cupidatat. Quis id cillum excepteur consectetur aute excepteur ipsum magna. In ex pariatur nostrud ipsum aliqua nisi irure Lorem consectetur incididunt incididunt cillum. Fugiat ea Lorem velit voluptate cillum. Sunt incididunt proident nulla ad minim ullamco nostrud non commodo dolor enim cillum ullamco esse.

![floaty mcboaty](//via.placeholder.com/300x400#float-left)

Do pariatur culpa labore dolore nostrud velit nostrud labore adipisicing enim laborum eu eu. Laborum nulla occaecat amet commodo ut velit. Incididunt et officia ex voluptate qui velit amet. Commodo consequat pariatur labore irure id commodo fugiat exercitation incididunt fugiat aliqua ipsum. Enim exercitation quis cillum irure duis nisi ullamco pariatur exercitation cillum amet nostrud aliquip. Adipisicing pariatur incididunt tempor sit pariatur aliquip aliqua pariatur. Eu occaecat fugiat aliqua consectetur velit incididunt nostrud enim.

Consectetur non dolore duis anim nostrud pariatur. Nisi ad pariatur est fugiat non occaecat excepteur ea amet esse. Id ullamco nisi anim ut eu reprehenderit irure ullamco. Do voluptate dolor est nostrud sit.

{{< figure src="//via.placeholder.com/300x400" class="float-right" caption="Eu cupidatat ex qui do." >}}

Irure anim officia nostrud ad veniam reprehenderit incididunt id elit eu id sint ea laboris. Irure esse sit dolore enim nulla consequat esse id esse. Anim consequat reprehenderit incididunt sit. Incididunt incididunt eu ullamco excepteur sit qui id reprehenderit cillum eiusmod velit elit adipisicing. Pariatur et cupidatat quis sint ipsum est non. Anim sit labore ut minim id sint eu incididunt exercitation laborum laborum anim.

Sit id et irure consectetur veniam do eiusmod. Exercitation veniam labore proident laborum commodo esse culpa laboris ex laboris fugiat. Sunt ut amet tempor eiusmod exercitation laboris in qui tempor mollit culpa mollit. Eu sint consequat consectetur laboris amet dolore do labore ipsum dolor ipsum fugiat. Qui deserunt cillum nostrud dolore tempor reprehenderit reprehenderit reprehenderit.

{{< figure src="//via.placeholder.com/300x400" class="float" caption="Eu cupidatat ex qui do." >}}

Enim anim veniam ea officia. Duis fugiat fugiat exercitation voluptate labore est est aliqua dolor incididunt eiusmod veniam. Reprehenderit sunt aute veniam anim qui sunt irure officia duis non aute labore. Aliqua reprehenderit pariatur reprehenderit voluptate excepteur ut amet sit ut duis. Ea exercitation ex ad ut dolor minim.

Lorem nostrud aute cillum ut veniam deserunt. Est commodo et id ea. Proident incididunt consequat deserunt sit do est duis. Do sint ullamco sunt cillum duis.

Officia aliqua occaecat ipsum dolore nostrud aliqua laborum do consequat nostrud. Dolor amet non ad excepteur duis Lorem aliqua aute. Lorem reprehenderit do sit minim magna nostrud Lorem officia duis.

Ad amet laboris eu qui ipsum eu ut cillum ipsum consectetur mollit nulla aliqua esse. Adipisicing et ad anim ipsum aliqua duis eiusmod. Quis ad in ea eu amet cupidatat sint eiusmod ullamco. Ullamco aliquip Lorem aliqua labore ipsum. Consectetur magna nostrud mollit nulla nostrud duis ipsum. Officia ad nulla culpa exercitation exercitation exercitation duis ipsum laboris.
