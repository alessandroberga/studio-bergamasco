---
title: "Word of God I"
passage: "Table Talk"
date: 2018-05-11T09:06:46+10:00
audio: "//www.archive.org/download/table_talk_martin_luther_1801_librivox/tabletalk_05_luther_128kb.mp3"
audio_duration: 14:39
audio_size: 14076118
preachers: "Martin Luther"
images: ["/img/freely-20445.jpg"]
series: ["Test"]
tags: ["bible","scripture", "historical"]
draft: false
---
Recording by Gillian Hedrie from [Librivox](https://librivox.org/selections-from-the-table-talk-of-martin-luther-by-martin-luther/)
