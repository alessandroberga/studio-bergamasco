---
title: "John Calvin: Institutes 2 11"
passage: "John 3:16"
date: 2018-05-03T20:12:30+10:00
audio: "//ia801403.us.archive.org/29/items/institutes_christian_religion2_1003_librivox/institutesofchristianreligion2_11_calvin_64kb.mp3"
audio_duration: 22:23
audio_size: 10748346
images: []
preachers: "John Calvin"
series: ["Test"]
tags: ["theology","redemption", "historical"]
draft: false
---
Public Domain recording from [librivox](https://librivox.org/institutes-of-the-christian-religion-book-two-by-john-calvin/)
