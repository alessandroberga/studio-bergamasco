---
title: "Kids"
subtitle: "Ministry with Children"
date: 2018-05-01T07:39:12+10:00
images: [/img/freely-10057.jpg]
tags: ["two_column","ministry"]
draft: false
---
  This is an example of multiple columns.

  Unfortunately it needs the author to write html to work (though I could put everything in the front matter!)
  <div class="row">
    <div class="6u 12u(mobilep)">
      <h3>Left Column</h3>
      <p>You can fill this in with <i>html</i> or *markdown* </p>
    </div>
    <div class="6u 12u(mobilep)">
      <h3>And another subheading</h3>
      <p>Adipiscing faucibus nunc placerat. Tempus adipiscing turpis non blandit accumsan eget lacinia nunc integer interdum amet aliquam ut orci non col ut ut praesent. Semper amet interdum mi. Phasellus enim laoreet ac ac commodo faucibus faucibus. Curae lorem ipsum adipiscing ac. Vivamus ornare laoreet odio vis praesent.</p>
    </div>
  </div>
